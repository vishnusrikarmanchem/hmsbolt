package com.CaseStudy.roomservice.controller;
 
import com.CaseStudy.roomservice.dto.RoomDTO;
import com.CaseStudy.roomservice.entity.Room;
import com.CaseStudy.roomservice.service.RoomService;
 
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
 
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
 


@RestController
@RequestMapping("/rooms")
public class RoomController {

    @Autowired
    private RoomService roomService;

    
    
    @PostMapping("/add")
    
    public Room addRoom(@RequestBody Room room) {
        return roomService.addRoom(room);
      }


    
    @PutMapping("/update/{id}")
    
    public Room updateRoom(@PathVariable Long id, @RequestBody Room room) {
        return roomService.updateRoom(id, room);
    }

    
    
    @DeleteMapping("/delete/{id}")
    
    public void deleteRoom(@PathVariable Long id) {
        roomService.deleteRoom(id);
    }

    @GetMapping("/getall")
    public List<Room> getAllRooms() {
        return roomService.getAllRooms();
    }
    
    @GetMapping("/getby/{id}")
    public RoomDTO getRoomById(@PathVariable Long id) {
        Room room = roomService.getRoomById(id);
        return new RoomDTO(
            room.getId(),
            room.getRoomNumber(),
            room.getType(),
            room.getPrice(),
            room.isAvailable()
        );
    }
    
    
}
