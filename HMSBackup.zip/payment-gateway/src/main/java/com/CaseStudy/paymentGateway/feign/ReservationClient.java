package com.CaseStudy.paymentGateway.feign;
 
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
 
import com.CaseStudy.paymentGateway.dto.ReservationDTO;
 
@FeignClient("RESERVATION-SERVICE")
public interface ReservationClient {
 
    @GetMapping("/reservations/getby/{id}")
    ReservationDTO getReservationById(@PathVariable("id") Long id);
    @GetMapping("reservations/getbyguestid/{guestId}")
	public ReservationDTO getReservationGuestId(@PathVariable Long guestId);
}
