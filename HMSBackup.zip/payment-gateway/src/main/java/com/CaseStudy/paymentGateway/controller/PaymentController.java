package com.CaseStudy.paymentGateway.controller;

import org.springframework.web.bind.annotation.*;

import com.CaseStudy.paymentGateway.service.PaymentService;
import com.CaseStudy.paymentGateway.dto.ReservationDTO;
import com.CaseStudy.paymentGateway.entity.Payment;
import com.CaseStudy.paymentGateway.feign.ReservationClient;

import org.springframework.beans.factory.annotation.Autowired;

@RestController
@RequestMapping("/payment")
public class PaymentController {


	@Autowired
	private PaymentService paymentService;

	@Autowired
	private ReservationClient reservationClient;


	

	@PostMapping("/create-payment-link")
	public String createPaymentLink(@RequestBody Payment payment) {

		String paymentLink = paymentService.createPaymentLink(payment);

		return paymentLink;

	}

	@GetMapping("/callback")
	public String paymentCallback(@RequestParam String razorpay_payment_id,
	                              @RequestParam String razorpay_payment_link_id,
	                              @RequestParam String razorpay_payment_link_status,
	                              @RequestParam String razorpay_payment_link_reference_id) {

	    if (!"paid".equals(razorpay_payment_link_status)) {
	        return "Payment failed";
	    }

	    String[] referenceParts = razorpay_payment_link_reference_id.split("_");
	    if (referenceParts.length < 2) {
	        return "Invalid reference ID format";
	    }

	    Long reservationId = Long.parseLong(referenceParts[1]);
	    ReservationDTO reservation = reservationClient.getReservationGuestId(reservationId);

	    return "Payment successful for reservation:\n" + reservation;
	}

	

}