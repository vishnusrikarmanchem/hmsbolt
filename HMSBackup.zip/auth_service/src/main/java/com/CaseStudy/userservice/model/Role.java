package com.CaseStudy.userservice.model;

public enum Role {
    OWNER, MANAGER, RECEPTIONIST;
}
